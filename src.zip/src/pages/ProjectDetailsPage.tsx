import React, { useEffect, useMemo, useState } from 'react';
import { MapPin } from 'lucide-react';

// ========= الإعدادات =========
const API_BASE = 'https://192.168.1.169:7012';

// ========= أنواع بسيطة =========
type LogicalNode = {
  type: 'GOAL' | 'OUTCOME' | 'OUTPUT' | 'ACTIVITY';
  title: string;
  children?: LogicalNode[];
};

type ProjectDetails = {
  id: string;
  name: string;
  description?: string;
  startDate?: string | null;
  endDate?: string | null;
  status?: number | null; // 1..5
  code?: string;
  location?: string | null;
  lastRefresh?: string | null;
  logicalFramework?: LogicalNode[];
};

type ReportItem = {
  id: string;
  title: string;
  type: string;
  createdAt: string;
  status: 'ready' | 'processing' | 'failed';
  viewUrl?: string;
  downloadUrl?: string;
};

type DonutDatum = { label: string; value: number };
type DonutCardData = { title: string; data: DonutDatum[] };

// --- Indicators (PIRS)
type IndicatorRow = {
  id: string;
  indicator: string;
  unit: string;
  dir: 'up' | 'down' | 'stable';
  baseline?: number | '';
  target?: number | '';
  fromRegistry?: string;
};

// --- Data Collection instruments
type InstrumentRow = {
  id: string;
  formId: string;
  title?: string;
  cadence: 'ME' | 'Q' | 'M' | 'Y';
  samplingMethod: 'census' | 'random' | 'stratified' | 'purposive';
  targetN?: number | '';
  notes?: string;
};

// ========= أدوات مساعدة =========
function getToken() {
  return localStorage.getItem('access_token') || sessionStorage.getItem('access_token');
}

// تنسيق تاريخ يتحمّل غياب الـ timezone
function fmtDate(d?: string | null) {
  if (!d) return '—';
  const needsZ = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/.test(d) && !/[Z+\-]\d{2}:?\d{2}$/.test(d);
  const iso = needsZ ? d + 'Z' : d;
  const x = new Date(iso);
  if (isNaN(x.getTime())) return '—';
  return x.toLocaleDateString() + ', ' + x.toLocaleTimeString();
}

function statusLabel(n?: number | null) {
  const map: Record<number, { label: string; color: string; bg: string }> = {
    1: { label: 'Planned',   color: 'text-blue-700',   bg: 'bg-blue-100' },
    2: { label: 'Active',    color: 'text-green-700',  bg: 'bg-green-100' },
    3: { label: 'OnHold',    color: 'text-slate-700',  bg: 'bg-slate-100' },
    4: { label: 'Completed', color: 'text-amber-700',  bg: 'bg-amber-100' },
    5: { label: 'Cancelled', color: 'text-red-700',    bg: 'bg-red-100' },
  };
  return map[n ?? -1] ?? { label: 'Unknown', color: 'text-slate-700', bg: 'bg-slate-100' };
}

function Skeleton({ className = '' }: { className?: string }) {
  return <div className={`animate-pulse bg-slate-200 rounded ${className}`} />;
}

function StatCard({ title, value }: { title: string; value: React.ReactNode }) {
  return (
    <div className="rounded-xl border border-slate-200 p-4 bg-white">
      <div className="text-sm text-slate-500">{title}</div>
      <div className="mt-2 text-2xl font-semibold text-slate-900">{value}</div>
    </div>
  );
}

function TabButton({
  active, onClick, children,
}: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      onClick={onClick}
      className={`px-3 py-2 text-sm rounded-lg transition
        ${active ? 'bg-slate-900 text-white' : 'text-slate-600 hover:bg-slate-100'}`}
    >
      {children}
    </button>
  );
}

function LogicalTree({ nodes }: { nodes: LogicalNode[] }) {
  return (
    <div className="text-sm">
      {nodes.map((n, i) => (
        <div key={i} className="pl-4 border-l-2 border-slate-200 mb-2">
          <div className="flex items-start gap-2">
            <div className="w-2 h-2 rounded-full bg-slate-400 mt-2" />
            <div>
              <div className="font-semibold">
                {n.type} — <span className="font-normal">{n.title}</span>
              </div>
              {n.children && n.children.length > 0 && (
                <div className="mt-2">
                  <LogicalTree nodes={n.children} />
                </div>
              )}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

// ======== Donut Chart (SVG خفيفة) =========
function DonutChart({ data, size = 220, thickness = 26 }: { data: DonutDatum[]; size?: number; thickness?: number }) {
  const total = Math.max(1, data.reduce((s, d) => s + d.value, 0));
  const radius = size / 2;
  const inner = radius - thickness;
  let start = 0;

  const palette = ['#6366F1','#22C55E','#F59E0B','#06B6D4','#EF4444','#8B5CF6','#10B981','#F97316','#3B82F6','#84CC16'];

  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="mx-auto">
      {total === 1 && data.every(d => d.value === 0) && (
        <circle cx={radius} cy={radius} r={inner + thickness/2} fill="none" stroke="#E5E7EB" strokeWidth={thickness} />
      )}
      {data.map((d, i) => {
        const angle = (d.value / total) * Math.PI * 2;
        const end = start + angle;
        const large = angle > Math.PI ? 1 : 0;

        const x1 = radius + (inner + thickness/2) * Math.cos(start);
        const y1 = radius + (inner + thickness/2) * Math.sin(start);
        const x2 = radius + (inner + thickness/2) * Math.cos(end);
        const y2 = radius + (inner + thickness/2) * Math.sin(end);

        const path = `M ${x1} ${y1} A ${inner + thickness/2} ${inner + thickness/2} 0 ${large} 1 ${x2} ${y2}`;
        start = end;
        return (
          <path key={i} d={path} stroke={palette[i % palette.length]} strokeWidth={thickness} fill="none" strokeLinecap="butt" />
        );
      })}
      <circle cx={radius} cy={radius} r={inner} fill="#fff" />
    </svg>
  );
}

function DonutCard({ title, data }: DonutCardData) {
  const palette = ['#6366F1','#22C55E','#F59E0B','#06B6D4','#EF4444','#8B5CF6','#10B981','#F97316','#3B82F6','#84CC16'];
  return (
    <div className="rounded-xl border border-slate-200 bg-white p-4">
      <div className="text-sm font-medium text-slate-800 mb-2">{title}</div>
      <DonutChart data={data} />
      <div className="mt-3 flex flex-wrap gap-3 text-xs">
        {data.map((d, i) => (
          <div key={i} className="flex items-center gap-2">
            <span className="inline-block w-3 h-3 rounded" style={{ backgroundColor: palette[i % palette.length] }} />
            <span className="text-slate-600">{d.label}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ========= صف التقارير =========
function ReportRow({ r }: { r: ReportItem }) {
  return (
    <div className="grid grid-cols-12 items-center gap-2 px-4 py-3">
      <div className="col-span-5">
        <div className="font-medium text-slate-800">{r.title}</div>
        <div className="text-xs text-slate-500">{r.type}</div>
      </div>
      <div className="col-span-3 text-sm text-slate-700">{fmtDate(r.createdAt)}</div>
      <div className="col-span-2">
        <span className={`text-xs px-2 py-1 rounded
          ${r.status === 'ready' ? 'bg-green-100 text-green-700' :
            r.status === 'processing' ? 'bg-amber-100 text-amber-700' :
            'bg-red-100 text-red-700'}`}>
          {r.status}
        </span>
      </div>
      <div className="col-span-2 text-sm">
        <div className="flex gap-3">
          {r.viewUrl && <a className="text-indigo-600 hover:underline" href={r.viewUrl} target="_blank" rel="noreferrer">View</a>}
          {r.downloadUrl && <a className="text-indigo-600 hover:underline" href={r.downloadUrl} target="_blank" rel="noreferrer">Download</a>}
        </div>
      </div>
    </div>
  );
}

// ===== Logical Framework helpers =====
type LFItemApi = {
  id: string;
  parentId: string | null;
  type: number; // 0..3
  name: string;
  description?: string;
};

const LF_TYPE: Record<number, LogicalNode['type']> = {
  0: 'GOAL',
  1: 'OUTCOME',
  2: 'OUTPUT',
  3: 'ACTIVITY',
};

function buildLogicalTree(items: LFItemApi[]): LogicalNode[] {
  const map = new Map<string, LogicalNode & { _id: string; _parentId: string | null }>();
  items.forEach((it) => {
    map.set(it.id, {
      type: LF_TYPE[it.type] ?? 'ACTIVITY',
      title: it.name ?? '',
      children: [],
      _id: it.id,
      _parentId: it.parentId,
    } as any);
  });

  const roots: (LogicalNode & { _id: string; _parentId: string | null })[] = [];

  map.forEach((node) => {
    if (node._parentId && map.has(node._parentId)) {
      const parent = map.get(node._parentId)! as any;
      (parent.children ||= []).push(node);
    } else {
      roots.push(node);
    }
  });

  const strip = (n: any): LogicalNode => ({
    type: n.type,
    title: n.title,
    children: (n.children || []).map(strip),
  });

  return roots.map(strip);
}

/** ===== Change status control (يعرض فقط الانتقالات المسموحة حسب منطق الدومين) ===== */
const ALLOWED_TRANSITIONS: Record<number, Array<{ label: string; to: number }>> = {
  // 1: Planned → Active أو Cancel
  1: [
    { label: 'Start (Active)', to: 2 },
    { label: 'Cancel', to: 5 },
  ],
  // 2: Active → OnHold أو Completed أو Cancel
  2: [
    { label: 'Put on hold', to: 3 },
    { label: 'Complete', to: 4 },
    { label: 'Cancel', to: 5 },
  ],
  // 3: OnHold → Active أو Cancel
  3: [
    { label: 'Start (Active)', to: 2 },
    { label: 'Cancel', to: 5 },
  ],
  // 4: Completed → لا انتقالات
  4: [],
  // 5: Cancelled → لا انتقالات
  5: [],
};

function ChangeStatusControl({
  current,
  onChange,
  busy,
}: {
  current: number | null | undefined;
  busy: boolean;
  onChange: (to: number) => void;
}) {
  const options = current == null ? [] : (ALLOWED_TRANSITIONS[current] ?? []);
  if (!options.length) {
    return (
      <button
        disabled
        className="px-3 py-2 text-sm rounded-lg border border-slate-200 bg-white text-slate-400"
        title="No allowed transitions"
      >
        Change status
      </button>
    );
  }
  return (
    <div className="relative">
      <select
        disabled={busy}
        className="px-3 py-2 text-sm rounded-lg border border-slate-200 bg-white"
        defaultValue=""
        onChange={(e) => {
          const v = e.target.value;
          if (!v) return;
          onChange(Number(v));
          e.currentTarget.value = '';
        }}
      >
        <option value="" disabled>
          {busy ? 'Updating…' : 'Change status'}
        </option>
        {options.map((op) => (
          <option key={op.to} value={op.to}>
            {op.label}
          </option>
        ))}
      </select>
    </div>
  );
}

// ========= الصفحة =========
export default function ProjectDetailsPage({
  projectId,
  onBack,
}: {
  projectId: string;
  onBack?: () => void;
}) {
  const [tab, setTab] = useState<'overview' | 'indicators' | 'data-collection' | 'responses' | 'reports' | 'team'>('overview');
  const [loading, setLoading] = useState(true);
  const [project, setProject] = useState<ProjectDetails | null>(null);
  const [error, setError] = useState<string | null>(null);

  // بيانات التبويبات الأخرى
  const [reports, setReports] = useState<ReportItem[]>([]);
  const [responses, setResponses] = useState<DonutCardData[]>([]);
  const [loadingExtras, setLoadingExtras] = useState(false);

  // عرض فقط حالياً
  const [indicators] = useState<IndicatorRow[]>([]);
  const [instruments] = useState<InstrumentRow[]>([]);

  // حالات خاصة بالـ Logical Framework
  const [lfLoading, setLfLoading] = useState(false);
  const [lfError, setLfError] = useState<string | null>(null);

  // تغيير الحالة
  const [changing, setChanging] = useState(false);
  const [changeErr, setChangeErr] = useState<string | null>(null);
  const [changeOk, setChangeOk] = useState<string | null>(null);

  // ====== جلب تفاصيل المشروع
  useEffect(() => {
    let mounted = true;
    async function load() {
      setLoading(true);
      setError(null);
      try {
        const token = getToken();
        if (!token) throw new Error('Not authenticated');

        const res = await fetch(`${API_BASE}/api/app/project/${projectId}`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (!res.ok) throw new Error(`Error ${res.status}`);
        const ct = res.headers.get('content-type') || '';
        if (!ct.includes('application/json')) {
          const text = await res.text();
          throw new Error(`Unexpected response. ${text.slice(0, 120)}`);
        }
        const data = await res.json();

        const normalized: ProjectDetails = {
          id: data.id,
          name: data.name ?? '',
          description: data.description ?? '',
          startDate: data.startDate ?? null,
          endDate: data.endDate ?? null,
          status: data.status ?? null,
          code: data.code ?? undefined,
          location: data.location ?? null,
          lastRefresh: data.lastModificationTime ?? data.creationTime ?? null,
          logicalFramework: [], // سيملأ من API منفصل
        };

        if (mounted) setProject(normalized);
      } catch (e: any) {
        if (mounted) setError(e?.message || 'Failed to load project');
      } finally {
        if (mounted) setLoading(false);
      }
    }

    if (projectId) load();
    return () => { mounted = false; };
  }, [projectId]);

  // جلب Logical Framework بالشجرة من parentId
  useEffect(() => {
    let mounted = true;

    async function loadLogicalFramework() {
      setLfLoading(true);
      setLfError(null);
      try {
        const token = getToken();
        if (!token) throw new Error('Not authenticated');

        const res = await fetch(
          `${API_BASE}/api/app/logical-framework-item/by-project-id/${projectId}`,
          { headers: { Authorization: `Bearer ${token}` } }
        );
        if (!res.ok) throw new Error(`Error ${res.status}`);

        const data = await res.json();
        const items: LFItemApi[] = Array.isArray(data?.items) ? data.items : [];
        const tree = buildLogicalTree(items);

        if (mounted) {
          setProject((prev) => (prev ? { ...prev, logicalFramework: tree } : prev));
        }
      } catch (e: any) {
        if (mounted) setLfError(e?.message || 'Failed to load logical framework');
      } finally {
        if (mounted) setLfLoading(false);
      }
    }

    if (projectId) loadLogicalFramework();
    return () => { mounted = false; };
  }, [projectId]);

  // جلب بيانات التقارير والردود (mock الآن)
  useEffect(() => {
    let mounted = true;
    async function fetchExtras() {
      setLoadingExtras(true);
      try {
        const sampleReports: ReportItem[] = [
          { id: 'r1', title: 'Narrative — Aug 2025', type: 'narrative', createdAt: '2025-08-15T13:34:00Z', status: 'ready', viewUrl: '#', downloadUrl: '#' },
          { id: 'r2', title: 'Annex — Indicator tables', type: 'annex', createdAt: '2025-08-01T11:10:00Z', status: 'ready', downloadUrl: '#' },
        ];
        const sampleResponses: DonutCardData[] = [
          { title: 'Gender', data: [{ label: 'Male', value: 52 }, { label: 'Female', value: 46 }, { label: 'Other', value: 2 }]},
          { title: 'Age Group', data: [{ label: '18-24', value: 18 }, { label: '25-34', value: 34 }, { label: '35-44', value: 24 }, { label: '45+', value: 24 }]},
          { title: 'Governorate', data: [{ label: 'دمشق', value: 22 }, { label: 'السويداء', value: 12 }, { label: 'حمص', value: 16 }, { label: 'دير الزور', value: 20 }, { label: 'درعا', value: 30 }]},
          { title: 'Education Level', data: [{ label: 'ثانوي', value: 20 }, { label: 'بكالوريوس', value: 50 }, { label: 'ماجستير', value: 20 }, { label: 'دكتوراه', value: 10 }]},
        ];
        if (!mounted) return;
        setReports(sampleReports);
        setResponses(sampleResponses);
      } finally {
        if (mounted) setLoadingExtras(false);
      }
    }
    fetchExtras();
    return () => { mounted = false; };
  }, [projectId]);

  const statCards = useMemo(() => ([
    { title: 'Submissions', value: '—' },
    { title: 'Respondents', value: '—' },
    { title: 'Completion rate', value: '—' },
  ]), []);

  // ===== تغيير الحالة (POST) =====
  async function postChangeStatus(targetStatus: number) {
    if (!project) return;
    setChanging(true);
    setChangeErr(null);
    setChangeOk(null);
    try {
      const token = getToken();
      if (!token) throw new Error('Not authenticated');

      const url = `${API_BASE}/api/app/project/${project.id}/change-status?status=${encodeURIComponent(
        String(targetStatus)
      )}`;

      const res = await fetch(url, {
        method: 'POST', // ← حسب طلبك
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (!res.ok) {
        let message = `Error ${res.status}`;
        try {
          const ct = res.headers.get('content-type') || '';
          if (ct.includes('application/json')) {
            const body = await res.json();
            message = body?.message || body?.error || message;
          } else {
            const text = await res.text();
            if (text) message = `${message}: ${text.slice(0, 180)}`;
          }
        } catch {}
        throw new Error(message);
      }

      const updated = await res.json();
      setProject((prev) =>
        prev
          ? {
              ...prev,
              status: updated?.status ?? targetStatus,
              lastRefresh: updated?.lastModificationTime ?? prev.lastRefresh,
            }
          : prev
      );
      setChangeOk('Status updated successfully.');
    } catch (e: any) {
      setChangeErr(e?.message || 'Failed to change status');
    } finally {
      setChanging(false);
      setTimeout(() => {
        setChangeOk(null);
        setChangeErr(null);
      }, 2500);
    }
  }

  // ===== Header
  const header = (
    <div className="rounded-2xl border border-slate-200 bg-white p-5">
      {loading ? (
        <>
          <Skeleton className="h-6 w-40" />
          <div className="mt-3 flex flex-wrap gap-3 items-center">
            <Skeleton className="h-5 w-20" />
            <Skeleton className="h-5 w-28" />
            <Skeleton className="h-5 w-36" />
          </div>
        </>
      ) : error ? (
        <div className="text-red-600">Error: {error}</div>
      ) : project ? (
        <div className="flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
          <div>
            <div className="flex items-center gap-3 flex-wrap">
              <h1 className="text-xl font-semibold text-slate-900">{project.name}</h1>
              {project.code && (
                <span className="text-xs px-2 py-1 rounded bg-slate-100 text-slate-700">
                  {project.code}
                </span>
              )}
              <span
                className={`text-xs px-2 py-1 rounded ${statusLabel(project.status).bg} ${statusLabel(project.status).color}`}
              >
                {statusLabel(project.status).label}
              </span>
            </div>

            <div className="mt-2 text-sm text-slate-500 flex flex-wrap gap-4">
              <div>
                <span className="font-medium text-slate-600">Last refresh:</span>{' '}
                {fmtDate(project.lastRefresh)}
              </div>
              <div>
                {fmtDate(project.startDate)} — {fmtDate(project.endDate)}
              </div>
              <div className="flex items-center gap-1">
                <MapPin size={14} className="text-slate-400" />
                <span className="font-medium text-slate-600">Location:</span>{' '}
                <span className="text-slate-700">{project.location || '—'}</span>
              </div>
            </div>

            {(changeErr || changeOk) && (
              <div className="mt-2 text-xs">
                {changeErr && <span className="text-red-600">{changeErr}</span>}
                {changeOk && <span className="text-green-700">{changeOk}</span>}
              </div>
            )}
          </div>

          <div className="flex gap-2">
            {/* زر تغيير الحالة (حسب منطق الدومين) */}
            <ChangeStatusControl
              current={project.status ?? null}
              busy={changing}
              onChange={postChangeStatus}
            />

            <button className="px-3 py-2 text-sm rounded-lg border border-slate-200 bg-white hover:bg-slate-50">
              Upload data
            </button>
            <button className="px-3 py-2 text-sm rounded-lg border border-slate-200 bg-white hover:bg-slate-50">
              Export
            </button>
            <button className="px-3 py-2 text-sm rounded-lg bg-slate-900 text-white hover:bg-slate-800">
              Edit
            </button>
          </div>
        </div>
      ) : null}
    </div>
  );

  // ===== Overview
  const overview = (
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {statCards.map((s) => (
          <StatCard key={s.title} title={s.title} value={s.value} />
        ))}
      </div>

      <div className="rounded-xl border border-slate-200 bg-white p-4">
        <div className="text-base font-semibold text-slate-900 mb-2">Logical framework</div>
        <div className="rounded-lg border border-slate-200 p-4">
          {lfLoading ? (
            <div className="space-y-2">
              <Skeleton className="h-4 w-40" />
              <Skeleton className="h-4 w-56" />
              <Skeleton className="h-4 w-48" />
            </div>
          ) : lfError ? (
            <div className="text-sm text-red-600">{lfError}</div>
          ) : project && project.logicalFramework && project.logicalFramework.length ? (
            <LogicalTree nodes={project.logicalFramework} />
          ) : (
            <div className="text-sm text-slate-500">No logical framework yet.</div>
          )}
        </div>
      </div>
    </div>
  );

  // ===== Responses
  const responsesTab = (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      {loadingExtras ? (
        Array.from({ length: 6 }).map((_, i) => (
          <div key={i} className="rounded-xl border border-slate-200 bg-white p-4">
            <Skeleton className="h-5 w-40 mb-4" />
            <Skeleton className="h-48 w-full" />
          </div>
        ))
      ) : (
        responses.map((c, i) => <DonutCard key={i} title={c.title} data={c.data} />)
      )}
    </div>
  );

  // ===== Reports
  const reportsTab = (
    <div className="rounded-xl border border-slate-200 bg-white overflow-hidden">
      <div className="grid grid-cols-12 gap-2 px-4 py-3 bg-slate-50 text-xs font-medium text-slate-600">
        <div className="col-span-5">Title</div>
        <div className="col-span-3">Created at</div>
        <div className="col-span-2">Status</div>
        <div className="col-span-2">Actions</div>
      </div>
      <div className="divide-y">
        {loadingExtras ? (
          Array.from({ length: 2 }).map((_, i) => (
            <div key={i} className="px-4 py-3">
              <Skeleton className="h-5 w-64 mb-2" />
              <Skeleton className="h-4 w-40" />
            </div>
          ))
        ) : reports.length ? (
          reports.map((r) => <ReportRow key={r.id} r={r} />)
        ) : (
          <div className="px-4 py-6 text-sm text-slate-500">No reports yet.</div>
        )}
      </div>
    </div>
  );

  // ===== Indicators (PIRS) — VIEW TABLE
  const prettyDir: Record<IndicatorRow['dir'], string> = {
    up: 'Increase',
    down: 'Decrease',
    stable: 'Maintain',
  };

  const indicatorsTab = (
    <div className="rounded-xl border border-slate-200 overflow-hidden bg-white">
      {/* Header */}
      <div className="grid grid-cols-12 gap-2 px-4 py-3 bg-slate-50 text-xs font-medium text-slate-600">
        <div className="col-span-4">Indicator</div>
        <div className="col-span-2">Unit</div>
        <div className="col-span-2">Direction</div>
        <div className="col-span-2">Baseline</div>
        <div className="col-span-2">Target (overall)</div>
      </div>

      {/* Body */}
      <div className="divide-y">
        {[] /* indicators */.length ? (
          [] /* indicators */.map((row: IndicatorRow) => (
            <div key={row.id} className="grid grid-cols-12 gap-2 px-4 py-3 text-sm text-slate-900">
              <div className="col-span-4">
                <div>{row.indicator || '—'}</div>
                {row.fromRegistry && (
                  <div className="text-xs text-slate-500 mt-1">from registry: {row.fromRegistry}</div>
                )}
              </div>
              <div className="col-span-2">{row.unit || '—'}</div>
              <div className="col-span-2 flex items-center gap-1">
                {row.dir === 'up' && <span aria-hidden>▲</span>}
                {row.dir === 'down' && <span aria-hidden>▼</span>}
                {row.dir === 'stable' && <span aria-hidden>■</span>}
                <span>{prettyDir[row.dir]}</span>
              </div>
              <div className="col-span-2">{row.baseline === '' || row.baseline == null ? '—' : row.baseline}</div>
              <div className="col-span-2">{row.target === '' || row.target == null ? '—' : row.target}</div>
            </div>
          ))
        ) : (
          <div className="px-4 py-6 text-sm text-slate-500">No indicators.</div>
        )}
      </div>
    </div>
  );

  // ===== Data Collection — VIEW TABLE
  const prettyCadence: Record<InstrumentRow['cadence'], string> = {
    ME: 'ME',
    M: 'Monthly',
    Q: 'Quarterly',
    Y: 'Yearly',
  };

  const prettySampling: Record<InstrumentRow['samplingMethod'], string> = {
    census: 'census',
    random: 'random',
    stratified: 'stratified',
    purposive: 'purposive',
  };

  const dataCollectionTab = (
    <div className="rounded-xl border border-slate-200 overflow-hidden bg-white">
      {/* Header */}
      <div className="grid grid-cols-12 gap-2 px-4 py-3 bg-slate-50 text-xs font-medium text-slate-600">
        <div className="col-span-2">Form ID</div>
        <div className="col-span-2">Title</div>
        <div className="col-span-2">Cadence</div>
        <div className="col-span-2">Sampling method</div>
        <div className="col-span-1">Target N</div>
        <div className="col-span-3">Notes</div>
      </div>

      {/* Body */}
      <div className="divide-y">
        {[] /* instruments */.length ? (
          [] /* instruments */.map((row: InstrumentRow) => (
            <div key={row.id} className="grid grid-cols-12 gap-2 px-4 py-3 text-sm text-slate-900">
              <div className="col-span-2">{row.formId || '—'}</div>
              <div className="col-span-2">{row.title || '—'}</div>
              <div className="col-span-2">{prettyCadence[row.cadence] || '—'}</div>
              <div className="col-span-2">{prettySampling[row.samplingMethod] || '—'}</div>
              <div className="col-span-1">{row.targetN === '' || row.targetN == null ? '—' : row.targetN}</div>
              <div className="col-span-3 whitespace-pre-wrap">{row.notes || '—'}</div>
            </div>
          ))
        ) : (
          <div className="px-4 py-6 text-sm text-slate-500">No instruments.</div>
        )}
      </div>
    </div>
  );

  const tabsBar = (
    <div className="flex gap-2">
      {(['overview','indicators','data-collection','responses','reports','team'] as const).map((t) => (
        <TabButton key={t} active={tab === t} onClick={() => setTab(t)}>
          {t.split('-').map(w => w[0].toUpperCase() + w.slice(1)).join(' ')}
        </TabButton>
      ))}
    </div>
  );

  const placeholder = (title: string) => (
    <div className="rounded-xl border border-slate-200 bg-white p-6 text-slate-500">
      {title} — coming soon
    </div>
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <button
          className="text-sm text-slate-600 hover:text-slate-900"
          onClick={() => (onBack ? onBack() : window.history.back())}
        >
          ← Back
        </button>
      </div>

      {header}

      <div className="flex items-center justify-between">
        <div className="text-sm text-slate-600">Project</div>
        {tabsBar}
      </div>

      {tab === 'overview' && overview}
      {tab === 'indicators' && indicatorsTab}
      {tab === 'data-collection' && dataCollectionTab}
      {tab === 'responses' && responsesTab}
      {tab === 'reports' && reportsTab}
      {tab === 'team' && placeholder('Team')}
    </div>
  );
}

// ========= Helpers =========
function cryptoId() {
  return Math.random().toString(36).slice(2, 10);
}

function numOrEmpty(v: string): number | '' {
  if (v === '') return '';
  const n = Number(v);
  return Number.isNaN(n) ? '' : n;
}
