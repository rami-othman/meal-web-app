import React, { useEffect, useState } from 'react';
import { LoginPage } from './components/LoginPage';
import { Sidebar } from './components/Sidebar';
import { HomePage } from './pages/HomePage';
import { ArchivePage } from './pages/ArchivePage';
import { UserManagementPage } from './pages/UserManagementPage';
import { FeedbackPage } from './pages/FeedbackPage';
import { CreateProjectPage } from './pages/CreateProjectPage';
import { Page } from './types';
import ProjectDetailsPage from './pages/ProjectDetailsPage';

// نوسّع نوع الصفحات الحالي بإضافة صفحة التفاصيل
type AppPage = Page | 'project-details';
type ListPage = 'home' | 'archive';



function App() {
  const [currentPage, setCurrentPage] = useState<AppPage>('home');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [selectedProjectId, setSelectedProjectId] = useState<string | null>(null);
const handleOpenProject = (projectId: string) => {
  setSelectedProjectId(projectId);
  setCurrentPage('project-details');
};

  // صفحة الرجوع عندما نكون في تفاصيل مشروع
  const [returnPage, setReturnPage] = useState<ListPage>('home');

  // لو في توكن محفوظ، اعتبر المستخدم مسجّل دخول
  useEffect(() => {
    const token =
      localStorage.getItem('access_token') ||
      sessionStorage.getItem('access_token');
    if (token) setIsLoggedIn(true);
  }, []);

  const handleLogin = () => {
    setIsLoggedIn(true);
    setCurrentPage('home');
  };

  // اختياري: زر تسجيل خروج
  const handleLogout = () => {
    localStorage.removeItem('access_token');
    localStorage.removeItem('refresh_token');
    localStorage.removeItem('id_token');
    sessionStorage.removeItem('access_token');
    sessionStorage.removeItem('refresh_token');
    sessionStorage.removeItem('id_token');
    setIsLoggedIn(false);
    setSelectedProjectId(null);
    setCurrentPage('home');
    setReturnPage('home');
  };

  // تنشئ دالة تفتح تفاصيل مشروع مع حفظ صفحة المصدر
  const openFrom =
    (from: ListPage) =>
    (projectId: string) => {
      setReturnPage(from);
      setSelectedProjectId(projectId);
      setCurrentPage('project-details');
    };

  const renderCurrentPage = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage onOpenProject={openFrom('home')} />;
   case 'archive':
  return <ArchivePage onOpenProject={openFrom('archive')} />;
      case 'user-management':
        return <UserManagementPage />;
      case 'feedback':
        return <FeedbackPage />;
      case 'new-project':
        return <CreateProjectPage />;
      case 'project-details':
        if (!selectedProjectId) {
          return (
            <div className="rounded-xl border bg-white p-6 text-center text-slate-600">
              No project selected.
            </div>
          );
        }
        return (
          <ProjectDetailsPage
            projectId={selectedProjectId}
            onBack={() => setCurrentPage(returnPage)}
          />
        );
      default:
        return <HomePage onOpenProject={openFrom('home')} />;
    }
  };

  if (!isLoggedIn) {
    return <LoginPage onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen bg-gray-50 flex">
      <Sidebar
        currentPage={currentPage as Page}
        onPageChange={(p: Page) => {
          // عندما ننتقل لقائمة، حدّث returnPage وصفّر الـ selection
          if (p === 'home' || p === 'archive') {
            setReturnPage(p);
          }
          setCurrentPage(p);
          setSelectedProjectId(null);
        }}
        isOpen={sidebarOpen}
        onToggle={() => setSidebarOpen(!sidebarOpen)}
        // onLogout={handleLogout} // إن حبيت تضيف زر خروج
      />

      <main className="flex-1 lg:ml-64 p-4 lg:p-8">
        <div className="max-w-7xl mx-auto">{renderCurrentPage()}</div>
      </main>
    </div>
  );
}

export default App;
